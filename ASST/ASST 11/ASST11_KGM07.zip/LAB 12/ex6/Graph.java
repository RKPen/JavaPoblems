import java.util.*;

public class Graph
{
    private final int MAX_VERTS = 20; 
    private Vertex[] vertexList;        // list of vertices
    private int [][] adjMat;         // adjacency matrix private 
    int nVerts;             // current number of vertices private 
     
   ///////////   YOUR CODE FOR THE "checkCyclic" METHOD SHOULD GO HERE  ////////

    
    
    
    
    
    
    //////////////////////////////////////////////////////////////////////

    
     public Graph() {      
        vertexList = new Vertex[MAX_VERTS]; 
        adjMat = new int[MAX_VERTS][MAX_VERTS]; 
        nVerts = 0; 
        for (int j = 0; j < MAX_VERTS; j++)  
            for(int k = 0; k < MAX_VERTS; k++) 
                adjMat[j][k] = 0; 
    }
    
     public void addVertex(char lab) { 
        vertexList[nVerts++] = new Vertex(lab); 
    } 
    
    public void addEdge(int start, int end) {   
        adjMat[start][end] = 1;
        adjMat[end][start] = 1;        
    }
    
    public void addEdge(char start, char end) { 
        int i=index(start);
        if (i<0) return;
        int j=index(end);
        if (j<0) return;
        adjMat[i][j] = 1;
         adjMat[j][i] = 1;  
    }
    
     public int  index(char v) { 
        for (int i = 0; i < MAX_VERTS; i++)     
            if (vertexList[i].label==v)
                return i;
        return -1;   
    } 
    
    public void displayVertex(int v) { 
        System.out.print(vertexList[v].label + " ");
    } 
    
    public int getAdjUnvisitedVertex(int v){    
        for(int j=0; j<nVerts; j++){
                    if(adjMat[v][j]==1 && vertexList[j].wasVisited==false)
                         return j;
        }
        return -1;
   }
   
   public boolean checkCyclic() {
        Stack theStack = new Stack();
        vertexList[0].wasVisited = true;
        displayVertex(0);
        theStack.push(0);
        while (!theStack.isEmpty()) {
            int v = getAdjUnvisitedVertex((int) theStack.peek());
            if (v == -1) {
                theStack.pop();
            } else {
                vertexList[v].wasVisited = true;
                displayVertex(v);
                theStack.push(v);
            }
        }
        for (int j = 0; j < nVerts; j++) {
            vertexList[j].wasVisited = true;
        }
        return false;

   }

}

