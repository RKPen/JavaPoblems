// REMOVE THE TWO COMMENTS BELOW WHEN YOU ARE DONE WITH IMPLEMENTING THE "checkCyclic" METHOD
// You can create the other graph and test it

public class CheckCyclic {    
    public static void main(String [] args) {
        Graph g = new Graph();
        g.addVertex('A');
        g.addVertex('B');
        g.addVertex('C');
        g.addVertex('D');
        g.addVertex('E');
        g.addVertex('F');
        
        g.addEdge('A', 'B');
        g.addEdge('A', 'C');
        g.addEdge('B', 'D');
        g.addEdge('C', 'E');
        g.addEdge('C', 'F');
        g.addEdge('E', 'D');
        g.addEdge('F', 'D');
        
        if(g.checkCyclic())
           System.out.println("The graph contains a cycle");
        else
           System.out.println("The graph has no cycles");
    }
}