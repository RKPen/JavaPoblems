import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class ex5 {

    
    private static void DFS(Graph graph, int v, boolean[] visited) {
        visited[v] = true;
        System.out.print(v + " ");
        for (int w : graph.adjList.get(v)) {
            if (!visited[w]) {
                DFS(graph, w, visited);
            }
        }

    }

    // Check if the graph is strongly connected or not
    public static boolean isStronglyConnected(Graph graph, int n) {

        for (int i = 0; i < n; i++) { //loop over all points
            boolean[] visited = new boolean[n];

            DFS(graph, i, visited);
            
            for (int j = 0; j < n; j++) {
                if (!visited[j]) {
                    return false;
                }
            }
            
        }

        return true;
    }

    public static void main(String[] args) {
        // List of graph edges as per the above diagram (strongly connected example)
        List<Edge> edges = Arrays.asList(
                new Edge(0, 4), new Edge(1, 0), new Edge(1, 2), new Edge(2, 1),
                new Edge(2, 4), new Edge(3, 1), new Edge(3, 2), new Edge(4, 3));

        // List of graph edges as per the above diagram (not strongly connected example)
        /*List<Edge> edges = Arrays.asList(
            new Edge(0, 4), new Edge(1, 4), new Edge(1, 2), new Edge(2, 1),
            new Edge(2, 4), new Edge(3, 1), new Edge(3, 2), new Edge(4, 3));*/

        // total number of nodes in the graph
        int n = 5;

        // construct graph
        Graph graph = new Graph(edges, n);

        // check if the graph is not strongly connected or not
        if (isStronglyConnected(graph, n)) {
            System.out.println("The graph is strongly connected");
        } else {
            System.out.println("The graph is not strongly connected");
        }
    }
}