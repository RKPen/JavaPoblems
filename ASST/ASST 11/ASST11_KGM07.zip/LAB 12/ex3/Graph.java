import java.util.*;

public class Graph { 
	private int MAX_VERTS = 20; 
	private Vertex vertexList[]; 		
	private int adjMat[][]; 		
	int nVerts; 			
	public Graph() {			
		vertexList = Vertex[MAX_VERTS]; 
		adjMat = new int[MAX_VERTS][MAX_VERTS];
		nVerts = 0; 
		for (int j = 0; j < MAX_VERTS; j++) 
			for(int k = 0; k < MAX_VERTS; k++) 
				adjMat[j][k] = 0; 
	}
   public void addVertex(char lab) { 
		vertexList[nVerts++] = new Vertex(lab); 
	} 
	public void addEdge(int start, int end) { 
						
		adjMat[start][end] = 1;
		 adjMat[end][start] = 1;  	
						
	}
	public void displayVertex(int v) { 
		System.out.print(vertexList[v].label);
	}
    public void DFS() { 
        vertexList[0].wasVisited = true; 
        displayVertex(0); 
        theStack.push(0); 
        while( !theStack.isEmpty() ) { 
            int v = getAdjUnvisitedVertex( theStack.peek() ); 
            if(v == -1) 
                theStack.pop(); 
            else { 
                vertexList[v].wasVisited = true; 
                displayVertex(v); 
                theStack.push(v); 
            } 
        } 
        for(int j = 0; j < nVerts; j++) 
            vertexList[j].wasVisited = false; 
    }
    
    public void BFS(){
        vertexList[0].wasVisited = true; 
        displayVertex(0); 
        theQueue.insert(0); 
        int v2; 
        while( !theQueue.isEmpty() ) { 
            int v1 = theQueue.remove(); 
            while( (v2=getAdjUnvisitedVertex(v1)) != -1 ) { 
                vertexList[v2].wasVisited = true; 
                displayVertex(v2); 
                theQueue.insert(v2); 
            } 
        } 
        for(int j = 0; j < nVerts; j++) 
            vertexList[j].wasVisited = false; 
    }

    //Shortest path method that prints the shortest path from a source vertex to each vertex in the
    //graph using Dijkstra’s algorithm.
    public void shortestPath(int source){
        int[] distance = new int[nVerts];
        int[] previous = new int[nVerts];
        boolean[] visited = new boolean[nVerts];
        for(int i = 0; i < nVerts; i++){
            distance[i] = Integer.MAX_VALUE;
            previous[i] = -1;
            visited[i] = false;
        }
        distance[source] = 0;
        for(int i = 0; i < nVerts; i++){
            int u = minDistance(distance, visited);
            visited[u] = true;
            for(int v = 0; v < nVerts; v++){
                if(!visited[v] && adjMat[u][v] != 0 && distance[u] != Integer.MAX_VALUE && distance[u] + adjMat[u][v] < distance[v]){
                    distance[v] = distance[u] + adjMat[u][v];
                    previous[v] = u;
                }
            }
        }
        for(int i = 0; i < nVerts; i++){
            System.out.print("Shortest path from " + vertexList[source].label + " to " + vertexList[i].label + ": ");
            printPath(previous, i);
            System.out.println("Distance: " + distance[i]);
        }
    }
}

