public class Rock implements Tossable {
    public void toss() {
        System.out.println("How many times can you make me bounce on the surface of water?");
    }
    public void bounce() {
        System.out.println("I'm a rock, I don't bounce!");
    }
}
    

