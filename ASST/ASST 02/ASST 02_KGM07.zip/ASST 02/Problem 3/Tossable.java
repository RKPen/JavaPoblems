public interface Tossable {
    public void toss();
    public void bounce();
    
}
